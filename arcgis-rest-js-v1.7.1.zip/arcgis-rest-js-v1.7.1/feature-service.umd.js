/* @preserve
* @esri/arcgis-rest-feature-service - v1.7.1 - Apache-2.0
* Copyright (c) 2017-2018 Esri, Inc.
* Fri Aug 10 2018 14:26:41 GMT-0700 (PDT)
*/
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@esri/arcgis-rest-request')) :
	typeof define === 'function' && define.amd ? define(['exports', '@esri/arcgis-rest-request'], factory) :
	(factory((global.arcgisRest = global.arcgisRest || {}),global.arcgisRest));
}(this, (function (exports,arcgisRestRequest) { 'use strict';

/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */



var __assign = Object.assign || function __assign(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
};

/**
 * Used internally by the package to ensure that first order request options are passed through as request parameters.
 */
function appendCustomParams(oldOptions, newOptions) {
    // only pass query parameters through in the request, not generic IRequestOptions props
    Object.keys(oldOptions).forEach(function (key) {
        if (key !== "url" &&
            key !== "params" &&
            key !== "authentication" &&
            key !== "httpMethod" &&
            key !== "fetch" &&
            key !== "portal" &&
            key !== "maxUrlLength") {
            newOptions.params[key] = oldOptions[key];
        }
    });
}

/* Copyright (c) 2017 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
/**
 * Get a feature by id.
 *
 * ```js
 * import { getFeature } from '@esri/arcgis-rest-feature-service';
 *
 * const url = "https://services.arcgis.com/V6ZHFr6zdgNZuVG0/arcgis/rest/services/Landscape_Trees/FeatureServer/0";
 *
 * getFeature({
 *   url,
 *   id: 42
 * };)
 *   .then(feature => {
 *     console.log(feature.attributes.FID); // 42
 *   });
 * ```
 *
 * @param requestOptions - Options for the request
 * @returns A Promise that will resolve with the feature.
 */
function getFeature(requestOptions) {
    var url = requestOptions.url + "/" + requestOptions.id;
    // default to a GET request
    var options = __assign({ httpMethod: "GET" }, requestOptions);
    return arcgisRestRequest.request(url, options).then(function (response) { return response.feature; });
}
/**
 * Query a feature service. See [REST Documentation](https://developers.arcgis.com/rest/services-reference/query-feature-service-layer-.htm) for more information.
 *
 * ```js
 * import { queryFeatures } from '@esri/arcgis-rest-feature-service';
 *
 * const url = "http://sampleserver6.arcgisonline.com/arcgis/rest/services/Census/MapServer/3";
 *
 * queryFeatures({
 *   url,
 *   where: "STATE_NAME = 'Alaska"
 * };)
 *   .then(feature => {
 *     console.log(feature.attributes.FID); // 42
 *   });
 * ```
 *
 * @param requestOptions - Options for the request
 * @returns A Promise that will resolve with the query response.
 */
function queryFeatures(requestOptions) {
    // default to a GET request
    var options = __assign({ params: {}, httpMethod: "GET", url: requestOptions.url }, requestOptions);
    appendCustomParams(requestOptions, options);
    // set default query parameters
    if (!options.params.where) {
        options.params.where = "1=1";
    }
    if (!options.params.outFields) {
        options.params.outFields = "*";
    }
    return arcgisRestRequest.request(options.url + "/query", options);
}

/* Copyright (c) 2017 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
/**
 * Add features request. See the [REST Documentation](https://developers.arcgis.com/rest/services-reference/add-features.htm) for more information.
 *
 * @param requestOptions - Options for the request.
 * ```js
 * import { addFeatures } from '@esri/arcgis-rest-feature-service';
 *
 * const url = "https://sampleserver6.arcgisonline.com/arcgis/rest/services/ServiceRequest/FeatureServer/0";
 *
 * addFeatures({
 *   url,
 *   adds: [{
 *     geometry: { x: -120, y: 45, spatialReference: { wkid: 4326 } },
 *     attributes: { status: "alive" }
 *   }]
 * });
 * ```
 *
 * @param requestOptions - Options for the request.
 * @returns A Promise that will resolve with the addFeatures response.
 */
function addFeatures(requestOptions) {
    var url = requestOptions.url + "/addFeatures";
    // edit operations are POST only
    var options = __assign({ params: {} }, requestOptions);
    appendCustomParams(requestOptions, options);
    // mixin, don't overwrite
    options.params.features = requestOptions.adds;
    delete options.params.adds;
    return arcgisRestRequest.request(url, options);
}

/* Copyright (c) 2017 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
/**
 * Update features request. See the [REST Documentation](https://developers.arcgis.com/rest/services-reference/update-features.htm) for more information.
 *
 * ```js
 * import { updateFeatures } from '@esri/arcgis-rest-feature-service';
 *
 * const url = "https://sampleserver6.arcgisonline.com/arcgis/rest/services/ServiceRequest/FeatureServer/0";
 *
 * updateFeatures({
 *   url,
 *   updates: [{
 *     geometry: { x: -120, y: 45, spatialReference: { wkid: 4326 } },
 *     attributes: { status: "alive" }
 *   }]
 * });
 * ```
 *
 * @param requestOptions - Options for the request.
 * @returns A Promise that will resolve with the updateFeatures response.
 */
function updateFeatures(requestOptions) {
    var url = requestOptions.url + "/updateFeatures";
    // edit operations are POST only
    var options = __assign({ params: {} }, requestOptions);
    appendCustomParams(requestOptions, options);
    // mixin, don't overwrite
    options.params.features = requestOptions.updates;
    delete options.params.updates;
    return arcgisRestRequest.request(url, options);
}

/* Copyright (c) 2017 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
/**
 * Delete features request. See the [REST Documentation](https://developers.arcgis.com/rest/services-reference/delete-features.htm) for more information.
 *
 * ```js
 * import { deleteFeatures } from '@esri/arcgis-rest-feature-service';
 *
 * const url = "https://sampleserver6.arcgisonline.com/arcgis/rest/services/ServiceRequest/FeatureServer/0";
 *
 * deleteFeatures({
 *   url,
 *   deletes: [1,2,3]
 * });
 * ```
 *
 * @param deleteFeaturesRequestOptions - Options for the request.
 * @returns A Promise that will resolve with the deleteFeatures response.
 */
function deleteFeatures(requestOptions) {
    var url = requestOptions.url + "/deleteFeatures";
    // edit operations POST only
    var options = __assign({ params: {} }, requestOptions);
    appendCustomParams(requestOptions, options);
    // mixin, don't overwrite
    options.params.objectIds = requestOptions.deletes;
    delete options.params.deletes;
    return arcgisRestRequest.request(url, options);
}

/* Copyright (c) 2018 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
/**
 * Request `attachmentInfos` of a feature by id. See [Attachment Infos](https://developers.arcgis.com/rest/services-reference/attachment-infos-feature-service-.htm) for more information.
 *
 * ```js
 * import { getAttachments } from '@esri/arcgis-rest-feature-service';
 *
 * getAttachments({
 *   url: "https://sampleserver6.arcgisonline.com/arcgis/rest/services/ServiceRequest/FeatureServer/0",
 *   featureId: 8484
 * });
 * ```
 *
 * @param requestOptions - Options for the request.
 * @returns A Promise that will resolve with the `getAttachments()` response.
 */
function getAttachments(requestOptions) {
    // pass through
    return arcgisRestRequest.request(requestOptions.url + "/" + requestOptions.featureId + "/attachments", requestOptions);
}

/* Copyright (c) 2018 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
/**
 * Attach a file to a feature by id. See [Add Attachment](https://developers.arcgis.com/rest/services-reference/add-attachment.htm) for more information.
 *
 * ```js
 * import { addAttachment } from '@esri/arcgis-rest-feature-service';
 *
 * addAttachment({
 *   url: "https://sampleserver6.arcgisonline.com/arcgis/rest/services/ServiceRequest/FeatureServer/0",
 *   featureId: 8484,
 *   attachment: myFileInput.files[0]
 * });
 * ```
 *
 * @param requestOptions - Options for the request.
 * @returns A Promise that will resolve with the `addAttachment()` response.
 */
function addAttachment(requestOptions) {
    var options = __assign({ params: {} }, requestOptions);
    // `attachment` --> params: {}
    options.params.attachment = requestOptions.attachment;
    return arcgisRestRequest.request(options.url + "/" + options.featureId + "/addAttachment", options);
}

/* Copyright (c) 2018 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
/**
 * Update a related attachment to a feature by id. See [Update Attachment](https://developers.arcgis.com/rest/services-reference/update-attachment.htm) for more information.
 *
 * ```js
 * import { updateAttachment } from '@esri/arcgis-rest-feature-service';
 *
 * updateAttachment({
 *   url: "https://sampleserver6.arcgisonline.com/arcgis/rest/services/ServiceRequest/FeatureServer/0",
 *   featureId: 8484,
 *   attachment: myFileInput.files[0],
 *   attachmentId: 306
 * });
 * ```
 *
 * @param requestOptions - Options for the request.
 * @returns A Promise that will resolve with the `updateAttachment()` response.
 */
function updateAttachment(requestOptions) {
    var options = __assign({ params: {} }, requestOptions);
    // `attachment` and `attachmentId` --> params: {}
    options.params.attachment = requestOptions.attachment;
    options.params.attachmentId = requestOptions.attachmentId;
    return arcgisRestRequest.request(options.url + "/" + options.featureId + "/updateAttachment", options);
}

/* Copyright (c) 2018 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
/**
 * Delete existing attachment files of a feature by id. See [Delete Attachments](https://developers.arcgis.com/rest/services-reference/delete-attachments.htm) for more information.
 *
 * ```js
 * import { deleteAttachments } from '@esri/arcgis-rest-feature-service';
 *
 * deleteAttachments({
 *   url: "https://sampleserver6.arcgisonline.com/arcgis/rest/services/ServiceRequest/FeatureServer/0",
 *   featureId: 8484,
 *   attachmentIds: [306]
 * });
 * ```
 *
 * @param requestOptions - Options for the request.
 * @returns A Promise that will resolve with the `deleteAttachments()` response.
 */
function deleteAttachments(requestOptions) {
    var options = __assign({ params: {} }, requestOptions);
    // `attachmentIds` --> params: {}
    options.params.attachmentIds = requestOptions.attachmentIds;
    return arcgisRestRequest.request(options.url + "/" + options.featureId + "/deleteAttachments", options);
}

/* Copyright (c) 2018 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
/**
 * Query the related records for a feature service. See the [REST Documentation](https://developers.arcgis.com/rest/services-reference/query-related-records-feature-service-.htm) for more information.
 *
 * ```js
 * import { queryRelated } from '@esri/arcgis-rest-feature-service'
 *
 * const url = "http://services.myserver/OrgID/ArcGIS/rest/services/Petroleum/KSPetro/FeatureServer/0"
 *
 * queryRelated({
 *  url: url,
 *  relationshipId: 1,
 *  params: { returnCountOnly: true }
 * })
 *  .then(response => {
 *    console.log(response.relatedRecords)
 *  })
 * ```
 *
 * @param requestOptions
 * @returns A Promise that will resolve with the query response
 */
function queryRelated(requestOptions) {
    var options = __assign({ params: {}, httpMethod: "GET", url: requestOptions.url }, requestOptions);
    appendCustomParams(requestOptions, options);
    if (!options.params.definitionExpression) {
        options.params.definitionExpression = "1=1";
    }
    if (!options.params.outFields) {
        options.params.outFields = "*";
    }
    if (!options.params.relationshipId) {
        options.params.relationshipId = 0;
    }
    return arcgisRestRequest.request(options.url + "/queryRelatedRecords", options);
}

exports.getFeature = getFeature;
exports.queryFeatures = queryFeatures;
exports.addFeatures = addFeatures;
exports.updateFeatures = updateFeatures;
exports.deleteFeatures = deleteFeatures;
exports.getAttachments = getAttachments;
exports.addAttachment = addAttachment;
exports.updateAttachment = updateAttachment;
exports.deleteAttachments = deleteAttachments;
exports.queryRelated = queryRelated;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=feature-service.umd.js.map
