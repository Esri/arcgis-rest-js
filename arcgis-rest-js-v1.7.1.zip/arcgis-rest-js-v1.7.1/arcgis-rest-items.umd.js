/* @esri/arcgis-rest-items - v1.1.2 - Thu May 10 2018 15:55:40 GMT-0700 (PDT)
 * Copyright (c) 2018 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@esri/arcgis-rest-request')) :
	typeof define === 'function' && define.amd ? define(['exports', '@esri/arcgis-rest-request'], factory) :
	(factory((global.arcgisRest = global.arcgisRest || {}),global.arcgisRest));
}(this, (function (exports,arcgisRestRequest) { 'use strict';

/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */



var __assign = Object.assign || function __assign(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
};

/* Copyright (c) 2017 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
/**
 * Search for items via the portal api
 *
 * ```js
 * import { searchItems } from '@esri/arcgis-rest-items';
 *
 * searchItems('water')
 * .then((results) => {
 *  console.log(response.results.total); // 355
 * })
 * ```
 *
 * @param search - A string or RequestOptions object to pass through to the endpoint.
 * @returns A Promise that will resolve with the data from the response.
 */
function searchItems(search) {
    var options = {
        httpMethod: "GET",
        params: {}
    };
    if (typeof search === "string") {
        options.params.q = search;
    }
    else {
        options.params = search.searchForm;
        // mixin, giving user supplied requestOptions precedence
        options = __assign({}, options, search);
    }
    // construct the search url
    var url = arcgisRestRequest.getPortalUrl(options) + "/search";
    // send the request
    return arcgisRestRequest.request(url, options);
}
/**
 * Create an item in a folder
 *
 * @param requestOptions = Options for the request
 */
function createItemInFolder(requestOptions) {
    var owner = requestOptions.owner ||
        requestOptions.item.owner ||
        requestOptions.authentication.username;
    var baseUrl = arcgisRestRequest.getPortalUrl(requestOptions) + "/content/users/" + owner;
    var url = baseUrl + "/addItem";
    if (requestOptions.folder) {
        url = baseUrl + "/" + requestOptions.folder + "/addItem";
    }
    // serialize the item into something Portal will accept
    requestOptions.params = __assign({}, requestOptions.params, serializeItem(requestOptions.item));
    return arcgisRestRequest.request(url, requestOptions);
}
/**
 * Create an Item in the user's root folder
 *
 * @param requestOptions - Options for the request
 */
function createItem(requestOptions) {
    // delegate to createItemInFolder placing in the root of the filestore
    var options = __assign({ folder: null }, requestOptions);
    return createItemInFolder(options);
}
/**
 * Send json to an item to be stored as the `/data` resource
 *
 * @param requestOptions - Options for the request
 */
function addItemJsonData(requestOptions) {
    var owner = requestOptions.owner || requestOptions.authentication.username;
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/content/users/" + owner + "/items/" + requestOptions.id + "/update";
    // Portal API requires that the 'data' be stringified and POSTed in
    // a `text` form field. It can also be sent with the `.create` call by sending
    // a `.data` property.
    requestOptions.params = __assign({}, requestOptions.params, { text: JSON.stringify(requestOptions.data) });
    return arcgisRestRequest.request(url, requestOptions);
}
/**
 * Get an item by id
 *
 * @param id - Item Id
 * @param requestOptions - Options for the request
 * @returns A Promise that will resolve with the data from the response.
 */
function getItem(id, requestOptions) {
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/content/items/" + id;
    // default to a GET request
    var options = __assign({ httpMethod: "GET" }, requestOptions);
    return arcgisRestRequest.request(url, options);
}
/**
 * Get the /data for an item.
 * Note: Some items do not return json from /data
 * and this method will throw if that is the case.
 *
 * @param id - Item Id
 * @param requestOptions - Options for the request
 * @returns A Promise that will resolve with the json data for the item.
 */
function getItemData(id, requestOptions) {
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/content/items/" + id + "/data";
    // default to a GET request
    var options = __assign({ httpMethod: "GET" }, requestOptions);
    return arcgisRestRequest.request(url, options);
}
/**
 * Update an Item
 *
 * @param item - The item to update.
 * @param requestOptions - Options for the request.
 * @returns A Promise that resolves with the status of the operation.
 */
function updateItem(requestOptions) {
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/content/users/" + requestOptions.item.owner + "/items/" + requestOptions.item.id + "/update";
    // serialize the item into something Portal will accept
    requestOptions.params = __assign({}, requestOptions.params, serializeItem(requestOptions.item));
    return arcgisRestRequest.request(url, requestOptions);
}
/**
 * Remove an item from the portal
 *
 * @param requestOptions - Options for the request
 * @returns A Promise that deletes an item.
 */
function removeItem(requestOptions) {
    var owner = requestOptions.owner || requestOptions.authentication.username;
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/content/users/" + owner + "/items/" + requestOptions.id + "/delete";
    return arcgisRestRequest.request(url, requestOptions);
}
/**
 * Protect an item
 *
 * @param requestOptions - Options for the request
 * @returns A Promise to protect an item.
 */
function protectItem(requestOptions) {
    var owner = requestOptions.owner || requestOptions.authentication.username;
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/content/users/" + owner + "/items/" + requestOptions.id + "/protect";
    return arcgisRestRequest.request(url, requestOptions);
}
/**
 * Unprotect an item
 *
 * @param requestOptions - Options for the request
 * @returns A Promise to unprotect an item.
 */
function unprotectItem(requestOptions) {
    var owner = requestOptions.owner || requestOptions.authentication.username;
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/content/users/" + owner + "/items/" + requestOptions.id + "/unprotect";
    return arcgisRestRequest.request(url, requestOptions);
}
/**
 * Get the resources associated with an item
 *
 * @param requestOptions - Options for the request
 * @returns A Promise to get some item resources.
 */
function getItemResources(requestOptions) {
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/content/items/" + requestOptions.id + "/resources";
    // mix in user supplied params
    requestOptions.params = __assign({}, requestOptions.params, { num: 1000 });
    return arcgisRestRequest.request(url, requestOptions);
}
/**
 * Update a resource associated with an item
 *
 * @param requestOptions - Options for the request
 * @returns A Promise to unprotect an item.
 */
function updateItemResource(requestOptions) {
    var owner = requestOptions.owner || requestOptions.authentication.username;
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/content/users/" + owner + "/items/" + requestOptions.id + "/updateResources";
    // mix in user supplied params
    requestOptions.params = __assign({}, requestOptions.params, { fileName: requestOptions.name, text: requestOptions.content });
    return arcgisRestRequest.request(url, requestOptions);
}
/**
 * Remove a resource associated with an item
 *
 * @param requestOptions - Options for the request
 * @returns A Promise to unprotect an item.
 */
function removeItemResource(requestOptions) {
    var owner = requestOptions.owner || requestOptions.authentication.username;
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/content/users/" + owner + "/items/" + requestOptions.id + "/removeResources";
    // mix in user supplied params
    requestOptions.params = __assign({}, requestOptions.params, { resource: requestOptions.resource });
    return arcgisRestRequest.request(url, requestOptions);
}
/**
 * Serialize an item into a json format accepted by the Portal API
 * for create and update operations
 *
 * @param item IItem to be serialized
 * @returns a formatted json object to be sent to Portal
 */
function serializeItem(item) {
    // create a clone so we're not messing with the original
    var clone = JSON.parse(JSON.stringify(item));
    // join keywords and tags...
    clone.typeKeywords = item.typeKeywords.join(", ");
    clone.tags = item.tags.join(", ");
    // convert .data to .text
    if (clone.data) {
        clone.text = JSON.stringify(clone.data);
        delete clone.data;
    }
    // Convert properties to a string
    if (clone.properties) {
        clone.properties = JSON.stringify(clone.properties);
    }
    return clone;
}

exports.searchItems = searchItems;
exports.createItemInFolder = createItemInFolder;
exports.createItem = createItem;
exports.addItemJsonData = addItemJsonData;
exports.getItem = getItem;
exports.getItemData = getItemData;
exports.updateItem = updateItem;
exports.removeItem = removeItem;
exports.protectItem = protectItem;
exports.unprotectItem = unprotectItem;
exports.getItemResources = getItemResources;
exports.updateItemResource = updateItemResource;
exports.removeItemResource = removeItemResource;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=arcgis-rest-items.umd.js.map
