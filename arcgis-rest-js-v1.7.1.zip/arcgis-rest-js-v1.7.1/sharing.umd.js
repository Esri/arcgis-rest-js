/* @preserve
* @esri/arcgis-rest-sharing - v1.7.1 - Apache-2.0
* Copyright (c) 2017-2018 Esri, Inc.
* Fri Aug 10 2018 14:27:03 GMT-0700 (PDT)
*/
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@esri/arcgis-rest-request')) :
	typeof define === 'function' && define.amd ? define(['exports', '@esri/arcgis-rest-request'], factory) :
	(factory((global.arcgisRest = global.arcgisRest || {}),global.arcgisRest));
}(this, (function (exports,arcgisRestRequest) { 'use strict';

/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */



var __assign = Object.assign || function __assign(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
};

/* Copyright (c) 2018 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
function getSharingUrl(requestOptions) {
    var username = requestOptions.authentication.username;
    var owner = requestOptions.owner || username;
    return arcgisRestRequest.getPortalUrl(requestOptions) + "/content/users/" + encodeURIComponent(owner) + "/items/" + requestOptions.id + "/share";
}
function isItemOwner(requestOptions) {
    var username = requestOptions.authentication.username;
    var owner = requestOptions.owner || username;
    return owner === username;
}
function isOrgAdmin(requestOptions) {
    var session = requestOptions.authentication;
    return session.getUser(requestOptions).then(function (user) {
        if (!user || user.role !== "org_admin") {
            return false;
        }
        else {
            return true;
        }
    });
}
function getUserMembership(requestOptions) {
    // start by assuming the user does not belong to the group
    var result = "nonmember";
    var session = requestOptions.authentication;
    // the response to this call is cached. yay!
    return session
        .getUser(requestOptions)
        .then(function (user) {
        if (user.groups) {
            user.groups.some(function (group) {
                var matchedGroup = group.id === requestOptions.groupId;
                if (matchedGroup) {
                    result = group.userMembership.memberType;
                }
                return matchedGroup;
            });
        }
        return result;
    })
        .catch(
    /* istanbul ignore next */ function (err) {
        throw Error("failure determining membership of " + session.username + " in group:" + requestOptions.groupId + ": " + err);
    });
}

/* Copyright (c) 2018 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
/**
 * Set access level of an item to 'public', 'org', or 'private'.
 *
 * ```js
 * import { setItemAccess } from '@esri/arcgis-rest-sharing';
 *
 * setItemAccess({
 *   id: "abc123",
 *   access: "public",
 *   authentication: session
 * })
 * ```
 *
 * @param requestOptions - Options for the request.
 * @returns A Promise that will resolve with the data from the response.
 */
function setItemAccess(requestOptions) {
    var url = getSharingUrl(requestOptions);
    if (isItemOwner(requestOptions)) {
        // if the user owns the item, proceed
        return updateItemAccess(url, requestOptions);
    }
    else {
        // otherwise we need to check to see if they are an organization admin
        return isOrgAdmin(requestOptions).then(function (admin) {
            if (admin) {
                return updateItemAccess(url, requestOptions);
            }
            else {
                // if neither, updating the sharing isnt possible
                throw Error("This item can not be shared by " + requestOptions.authentication.username + ". They are neither the item owner nor an organization admin.");
            }
        });
    }
}
function updateItemAccess(url, requestOptions) {
    requestOptions.params = __assign({ org: false, everyone: false }, requestOptions.params);
    // if the user wants to make the item private, it needs to be unshared from any/all groups as well
    if (requestOptions.access === "private") {
        requestOptions.params.groups = " ";
    }
    if (requestOptions.access === "org") {
        requestOptions.params.org = true;
    }
    // if sharing with everyone, share with the entire organization as well.
    if (requestOptions.access === "public") {
        requestOptions.params.org = true;
        requestOptions.params.everyone = true;
    }
    return arcgisRestRequest.request(url, requestOptions);
}

/* Copyright (c) 2018 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
/**
 * Share an item with a group.
 *
 * ```js
 * import { shareItemWithGroup } from '@esri/arcgis-rest-sharing';
 *
 * shareItemWithGroup({
 *   id: "abc123",
 *   groupId: "xyz987",
 *   authentication: session
 * })
 * ```
 *
 * @param requestOptions - Options for the request.
 * @returns A Promise that will resolve with the data from the response.
 */
function shareItemWithGroup(requestOptions) {
    return changeGroupSharing(__assign({ action: "share" }, requestOptions));
}
/**
 * Stop sharing an item with a group.
 *
 * ```js
 * import { unshareItemWithGroup } from '@esri/arcgis-rest-sharing';
 *
 * unshareItemWithGroup({
 *   id: "abc123",
 *   groupId: "xyz987",
 *   authentication: session
 * })
 * ```
 *
 * @param requestOptions - Options for the request.
 * @returns A Promise that will resolve with the data from the response.
 */
function unshareItemWithGroup(requestOptions) {
    return changeGroupSharing(__assign({ action: "unshare" }, requestOptions));
}
/**
 * @param requestOptions - Options for the request.
 * @returns A Promise that will resolve with the data from the response.
 */
function changeGroupSharing(requestOptions) {
    var username = requestOptions.authentication.username;
    var owner = requestOptions.owner || username;
    return isOrgAdmin(requestOptions).then(function (admin) {
        var resultProp = requestOptions.action === "share" ? "notSharedWith" : "notUnsharedFrom";
        // check if the item has already been shared with the group...
        return isItemSharedWithGroup(requestOptions).then(function (result) {
            // console.log(admin);
            // if we are sharing and result is true OR we are unsharing and result is false... short circuit
            if ((requestOptions.action === "share" && result === true) ||
                (requestOptions.action === "unshare" && result === false)) {
                // and send back the same response structure ArcGIS Online would
                var response = { itemId: requestOptions.id, shortcut: true };
                response[resultProp] = [];
                return response;
            }
            else {
                // next check to ensure the user is a member of the group
                return getUserMembership(requestOptions)
                    .then(function (membership) {
                    if (membership === "nonmember") {
                        // abort and reject promise
                        throw Error("This item can not be " + requestOptions.action + "d by " + username + " as they are not a member of the specified group " + requestOptions.groupId + ".");
                    }
                    else {
                        // if orgAdmin or owner (and member of group) share using the owner url
                        if (owner === username || admin) {
                            return arcgisRestRequest.getPortalUrl(requestOptions) + "/content/users/" + owner + "/items/" + requestOptions.id + "/" + requestOptions.action;
                        }
                        else {
                            // if they are a group admin/owner, use the bare item url
                            if (membership === "admin") {
                                return arcgisRestRequest.getPortalUrl(requestOptions) + "/content/items/" + requestOptions.id + "/" + requestOptions.action;
                            }
                            else {
                                // otherwise abort
                                throw Error("This item can not be " + requestOptions.action + "d by " + username + " as they are neither the owner, a groupAdmin of " + requestOptions.groupId + ", nor an org_admin.");
                            }
                        }
                    }
                })
                    .then(function (url) {
                    // now its finally time to do the sharing
                    requestOptions.params = {
                        groups: requestOptions.groupId,
                        confirmItemControl: requestOptions.confirmItemControl
                    };
                    // dont mixin to ensure that old query parameters from the search request arent included
                    return arcgisRestRequest.request(url, requestOptions);
                })
                    .then(function (sharingResponse) {
                    if (sharingResponse[resultProp].length) {
                        throw Error("Item " + requestOptions.id + " could not be " + requestOptions.action + "d to group " + requestOptions.groupId + ".");
                    }
                    else {
                        // all is well
                        return sharingResponse;
                    }
                });
            } // else
        }); // then
    });
}
/**
 * Find out whether or not an item is already shared with a group.
 *
 * @param requestOptions - Options for the request.
 * @returns A Promise that will resolve with the data from the response.
 */
function isItemSharedWithGroup(requestOptions) {
    var query = {
        q: "id: " + requestOptions.id + " AND group: " + requestOptions.groupId,
        start: 1,
        num: 10,
        sortField: "title"
    };
    // instead of calling out to "@esri/arcgis-rest-items, make the request manually to forgoe another dependency
    requestOptions.params = __assign({}, query, requestOptions.params);
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/search";
    return arcgisRestRequest.request(url, requestOptions).then(function (searchResponse) {
        // if there are no search results at all, we know the item hasnt already been shared with the group
        if (searchResponse.total === 0) {
            return false;
        }
        else {
            var sharedItem_1;
            // otherwise loop through and search for the id
            searchResponse.results.some(function (item) {
                var matchedItem = item.id === requestOptions.id;
                if (matchedItem) {
                    sharedItem_1 = item;
                }
                return matchedItem;
            });
            if (sharedItem_1) {
                return true;
            }
            else {
                return false;
            }
        }
    });
}

exports.setItemAccess = setItemAccess;
exports.shareItemWithGroup = shareItemWithGroup;
exports.unshareItemWithGroup = unshareItemWithGroup;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=sharing.umd.js.map
