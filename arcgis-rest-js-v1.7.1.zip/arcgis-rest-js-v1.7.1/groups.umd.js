/* @preserve
* @esri/arcgis-rest-groups - v1.7.1 - Apache-2.0
* Copyright (c) 2017-2018 Esri, Inc.
* Fri Aug 10 2018 14:26:51 GMT-0700 (PDT)
*/
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@esri/arcgis-rest-request')) :
	typeof define === 'function' && define.amd ? define(['exports', '@esri/arcgis-rest-request'], factory) :
	(factory((global.arcgisRest = global.arcgisRest || {}),global.arcgisRest));
}(this, (function (exports,arcgisRestRequest) { 'use strict';

/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */



var __assign = Object.assign || function __assign(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
};

/* Copyright (c) 2017-2018 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
/**
 * Search for groups via the portal api
 *
 * ```js
 * import { searchGroups } from '@esri/arcgis-rest-groups';
 *
 * searchgroups({q:'water'})
 * .then((results) => {
 *  console.log(response.results.total); // 355
 * })
 * ```
 *
 * @param searchForm - Search request
 * @param requestOptions - Options for the request
 * @returns A Promise that will resolve with the data from the response.
 */
function searchGroups(searchForm, requestOptions) {
    // construct the search url
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/community/groups";
    // default to a GET
    var options = __assign({ httpMethod: "GET" }, requestOptions);
    options.params = __assign({}, searchForm);
    // send the request
    return arcgisRestRequest.request(url, options);
}
/**
 *
 * @param id - Group Id
 * @param requestOptions  - Options for the request
 * @returns  A Promise that will resolve with the data from the response.
 */
function getGroup(id, requestOptions) {
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/community/groups/" + id;
    // default to a GET request
    var options = __assign({ httpMethod: "GET" }, requestOptions);
    return arcgisRestRequest.request(url, options);
}
/**
 * Returns the content of a Group. Since the group may contain 1000s of items
 * the requestParams allow for paging.
 * @param id - Group Id
 * @param requestOptions  - Options for the request, including paging parameters.
 * @returns  A Promise that will resolve with the content of the group.
 */
function getGroupContent(id, requestOptions) {
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/content/groups/" + id;
    // default to a GET request
    var options = __assign({ httpMethod: "GET" }, { params: { start: 1, num: 100 } }, requestOptions);
    // is this the most concise way to mixin with the defaults above?
    if (requestOptions && requestOptions.paging) {
        options.params = __assign({}, requestOptions.paging);
    }
    return arcgisRestRequest.request(url, options);
}
/**
 * Get the usernames of the admins and members. Does not return actual 'User' objects. Those must be
 * retrieved via separate calls to the User's API.
 * @param id - Group Id
 * @param requestOptions - Options for the request
 * @returns A Promise that will resolve with arrays of the group admin usernames and the member usernames
 */
function getGroupUsers(id, requestOptions) {
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/community/groups/" + id + "/users";
    // default to a GET request
    var options = __assign({ httpMethod: "GET" }, requestOptions);
    return arcgisRestRequest.request(url, options);
}
/**
 * Create a new Group.
 * Note: The group name must be unique within the user's organization.
 * @param requestOptions  - Options for the request, including a group object
 * @returns A Promise that will resolve with the success/failure status of the request
 */
function createGroup(requestOptions) {
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/community/createGroup";
    var options = __assign({}, requestOptions);
    // serialize the group into something Portal will accept
    options.params = serializeGroup(requestOptions.group);
    return arcgisRestRequest.request(url, options);
}
/**
 * Update the properties of a group - title, tags etc.
 * @param requestOptions - Options for the request, including the group
 * @returns A Promise that will resolve with the success/failure status of the request
 */
function updateGroup(requestOptions) {
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/community/groups/" + requestOptions.group.id + "/update";
    var options = __assign({}, requestOptions);
    // serialize the group into something Portal will accept
    options.params = serializeGroup(requestOptions.group);
    return arcgisRestRequest.request(url, options);
}
/**
 * Delete a group.
 * @param requestOptions - Options for the request
 * @returns A Promise that will resolve with the success/failure status of the request
 */
function removeGroup(requestOptions) {
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/community/groups/" + requestOptions.id + "/delete";
    var options = __assign({}, requestOptions);
    return arcgisRestRequest.request(url, options);
}
/**
 * Protect a Group. This simply means a user must unprotect the group prior to deleting it
 * @param requestOptions - Options for the request
 * @returns A Promise that will resolve with the success/failure status of the request
 */
function protectGroup(requestOptions) {
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/community/groups/" + requestOptions.id + "/protect";
    var options = __assign({}, requestOptions);
    return arcgisRestRequest.request(url, options);
}
/**
 * Unprotect a Group.
 * @param requestOptions - Options for the request
 * @returns A Promise that will resolve with the success/failure status of the request
 */
function unprotectGroup(requestOptions) {
    var url = arcgisRestRequest.getPortalUrl(requestOptions) + "/community/groups/" + requestOptions.id + "/unprotect";
    var options = __assign({}, requestOptions);
    return arcgisRestRequest.request(url, options);
}
/**
 * Serialize a group into a json format accepted by the Portal API
 * for create and update operations
 *
 * @param group IGroup to be serialized
 * @returns a formatted JSON object to be sent to Portal
 */
function serializeGroup(group) {
    // create a clone so we're not messing with the original
    var clone = JSON.parse(JSON.stringify(group));
    // join and tags...
    clone.tags = clone.tags.join(", ");
    return clone;
}

exports.searchGroups = searchGroups;
exports.getGroup = getGroup;
exports.getGroupContent = getGroupContent;
exports.getGroupUsers = getGroupUsers;
exports.createGroup = createGroup;
exports.updateGroup = updateGroup;
exports.removeGroup = removeGroup;
exports.protectGroup = protectGroup;
exports.unprotectGroup = unprotectGroup;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=groups.umd.js.map
