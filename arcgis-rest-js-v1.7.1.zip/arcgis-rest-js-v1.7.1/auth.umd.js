/* @preserve
* @esri/arcgis-rest-auth - v1.7.1 - Apache-2.0
* Copyright (c) 2017-2018 Esri, Inc.
* Fri Aug 10 2018 14:26:41 GMT-0700 (PDT)
*/
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@esri/arcgis-rest-request')) :
	typeof define === 'function' && define.amd ? define(['exports', '@esri/arcgis-rest-request'], factory) :
	(factory((global.arcgisRest = global.arcgisRest || {}),global.arcgisRest));
}(this, (function (exports,arcgisRestRequest) { 'use strict';

/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */



var __assign = Object.assign || function __assign(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
};

/* Copyright (c) 2017 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
function fetchToken(url, requestOptions) {
    // TODO: remove union type and type guard next breaking change and just expect IGenerateTokenRequestOptions
    var options = requestOptions
        .params
        ? requestOptions
        : { params: requestOptions };
    return arcgisRestRequest.request(url, options).then(function (response) {
        var r = {
            token: response.access_token,
            username: response.username,
            expires: new Date(Date.now() + (response.expires_in * 60 * 1000 - 60 * 1000))
        };
        if (response.refresh_token) {
            r.refreshToken = response.refresh_token;
        }
        return r;
    });
}

/* Copyright (c) 2017 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
var ApplicationSession = /** @class */ (function () {
    function ApplicationSession(options) {
        this.clientId = options.clientId;
        this.clientSecret = options.clientSecret;
        this.token = options.token;
        this.expires = options.expires;
        this.portal = "https://www.arcgis.com/sharing/rest";
        this.duration = options.duration || 20160;
    }
    // url isnt actually read or passed through.
    ApplicationSession.prototype.getToken = function (url, requestOptions) {
        if (this.token && this.expires && this.expires.getTime() > Date.now()) {
            return Promise.resolve(this.token);
        }
        if (this._pendingTokenRequest) {
            return this._pendingTokenRequest;
        }
        this._pendingTokenRequest = this.refreshToken(requestOptions);
        return this._pendingTokenRequest;
    };
    ApplicationSession.prototype.refreshToken = function (requestOptions) {
        var _this = this;
        var options = __assign({ params: {
                client_id: this.clientId,
                client_secret: this.clientSecret,
                grant_type: "client_credentials"
            } }, requestOptions);
        return fetchToken(this.portal + "/oauth2/token/", options).then(function (response) {
            _this._pendingTokenRequest = null;
            _this.token = response.token;
            _this.expires = response.expires;
            return response.token;
        });
    };
    ApplicationSession.prototype.refreshSession = function () {
        var _this = this;
        return this.refreshToken().then(function () { return _this; });
    };
    return ApplicationSession;
}());

/* Copyright (c) 2017-2018 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
function generateToken(url, requestOptions) {
    // TODO: remove union type and type guard next breaking change and just expect IGenerateTokenRequestOptions
    var options = requestOptions
        .params
        ? requestOptions
        : { params: requestOptions };
    /* istanbul ignore else */
    if (typeof window !== "undefined" &&
        window.location &&
        window.location.host) {
        options.params.referer = window.location.host;
    }
    else {
        options.params.referer = "@esri.arcgis-rest-auth";
    }
    return arcgisRestRequest.request(url, options);
}

/* Copyright (c) 2017-2018 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
function defer() {
    var deferred = {
        promise: null,
        resolve: null,
        reject: null
    };
    deferred.promise = new Promise(function (resolve, reject) {
        deferred.resolve = resolve;
        deferred.reject = reject;
    });
    return deferred;
}
/**
 * ```js
 * const session = new UserSession({
 *   username: "jsmith",
 *   password: "123456"
 * })
 * ```
 * Used to manage the authentication of ArcGIS Online and ArcGIS Enterprise users
 * in `request`. This class also includes several
 * helper methods for authenticating users with [OAuth 2.0](https://developers.arcgis.com/documentation/core-concepts/security-and-authentication/browser-based-user-logins/) in both browser and
 * server applications.
 *
 */
var UserSession = /** @class */ (function () {
    function UserSession(options) {
        this.clientId = options.clientId;
        this._refreshToken = options.refreshToken;
        this._refreshTokenExpires = options.refreshTokenExpires;
        this.username = options.username;
        this.password = options.password;
        this._token = options.token;
        this._tokenExpires = options.tokenExpires;
        this.portal = options.portal || "https://www.arcgis.com/sharing/rest";
        this.provider = options.provider || "arcgis";
        this.tokenDuration = options.tokenDuration || 20160;
        this.redirectUri = options.redirectUri;
        this.refreshTokenTTL = options.refreshTokenTTL || 1440;
        this.trustedServers = {};
        this._pendingTokenRequests = {};
    }
    Object.defineProperty(UserSession.prototype, "token", {
        /**
         * The current ArcGIS Online or ArcGIS Enterprise `token`.
         */
        get: function () {
            return this._token;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(UserSession.prototype, "tokenExpires", {
        /**
         * The expiration time of the current `token`.
         */
        get: function () {
            return this._tokenExpires;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(UserSession.prototype, "refreshToken", {
        /**
         * The current token to ArcGIS Online or ArcGIS Enterprise.
         */
        get: function () {
            return this._refreshToken;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(UserSession.prototype, "refreshTokenExpires", {
        /**
         * The expiration time of the current `refreshToken`.
         */
        get: function () {
            return this._refreshTokenExpires;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * Begins a new browser-based OAuth 2.0 sign in. If `options.popup` is true the
     * authentication window will open in a new tab/window otherwise the user will
     * be redirected to the authorization page in their current tab.
     *
     * @browserOnly
     */
    /* istanbul ignore next */
    UserSession.beginOAuth2 = function (options, win) {
        if (win === void 0) { win = window; }
        var _a = __assign({
            portal: "https://www.arcgis.com/sharing/rest",
            provider: "arcgis",
            duration: 20160,
            popup: true,
            state: options.clientId,
            locale: ""
        }, options), portal = _a.portal, provider = _a.provider, clientId = _a.clientId, duration = _a.duration, redirectUri = _a.redirectUri, popup = _a.popup, state = _a.state, locale = _a.locale;
        var url;
        if (provider === "arcgis") {
            url = portal + "/oauth2/authorize?client_id=" + clientId + "&response_type=token&expiration=" + duration + "&redirect_uri=" + encodeURIComponent(redirectUri) + "&state=" + state + "&locale=" + locale;
        }
        else {
            url = portal + "/oauth2/social/authorize?client_id=" + clientId + "&socialLoginProviderName=" + provider + "&autoAccountCreateForSocial=true&response_type=token&expiration=" + duration + "&redirect_uri=" + encodeURIComponent(redirectUri) + "&state=" + state + "&locale=" + locale;
        }
        if (!popup) {
            win.location.href = url;
            return undefined;
        }
        var session = defer();
        win["__ESRI_REST_AUTH_HANDLER_" + clientId] = function (errorString, oauthInfoString) {
            if (errorString) {
                var error = JSON.parse(errorString);
                session.reject(new arcgisRestRequest.ArcGISAuthError(error.errorMessage, error.error));
                return;
            }
            if (oauthInfoString) {
                var oauthInfo = JSON.parse(oauthInfoString);
                session.resolve(new UserSession({
                    clientId: clientId,
                    portal: portal,
                    token: oauthInfo.token,
                    tokenExpires: new Date(oauthInfo.expires),
                    username: oauthInfo.username
                }));
            }
        };
        win.open(url, "oauth-window", "height=400,width=600,menubar=no,location=yes,resizable=yes,scrollbars=yes,status=yes");
        return session.promise;
    };
    /**
     * Completes a browser-based OAuth 2.0 sign if `options.popup` is true the user
     * will be returned to the previous window. Otherwise a new `UserSession`
     * will be returned.
     *
     * @browserOnly
     */
    /* istanbul ignore next */
    UserSession.completeOAuth2 = function (options, win) {
        if (win === void 0) { win = window; }
        var _a = __assign({ portal: "https://www.arcgis.com/sharing/rest" }, options), portal = _a.portal, clientId = _a.clientId;
        function completeSignIn(error, oauthInfo) {
            if (win.opener && win.opener.parent) {
                win.opener.parent["__ESRI_REST_AUTH_HANDLER_" + clientId](error ? JSON.stringify(error) : undefined, JSON.stringify(oauthInfo));
                win.close();
                return undefined;
            }
            if (win !== win.parent) {
                win.parent["__ESRI_REST_AUTH_HANDLER_" + clientId](error ? JSON.stringify(error) : undefined, JSON.stringify(oauthInfo));
                win.close();
                return undefined;
            }
            if (error) {
                throw new arcgisRestRequest.ArcGISAuthError(error.errorMessage, error.error);
            }
            return new UserSession({
                clientId: clientId,
                portal: portal,
                token: oauthInfo.token,
                tokenExpires: oauthInfo.expires,
                username: oauthInfo.username
            });
        }
        var match = win.location.href.match(/access_token=(.+)&expires_in=(.+)&username=([^&]+)/);
        if (!match) {
            var errorMatch = win.location.href.match(/error=(.+)&error_description=(.+)/);
            var error = errorMatch[1];
            var errorMessage = decodeURIComponent(errorMatch[2]);
            return completeSignIn({ error: error, errorMessage: errorMessage });
        }
        var token = match[1];
        var expires = new Date(Date.now() + parseInt(match[2], 10) * 1000 - 60 * 1000);
        var username = decodeURIComponent(match[3]);
        return completeSignIn(undefined, {
            token: token,
            expires: expires,
            username: username
        });
    };
    /**
     * Begins a new server-based OAuth 2.0 sign in. This will redirect the user to
     * the ArcGIS Online or ArcGIS Enterprise authorization page.
     *
     * @nodeOnly
     */
    UserSession.authorize = function (options, response) {
        var _a = __assign({ portal: "https://arcgis.com/sharing/rest", duration: 20160 }, options), portal = _a.portal, clientId = _a.clientId, duration = _a.duration, redirectUri = _a.redirectUri;
        response.writeHead(301, {
            Location: portal + "/oauth2/authorize?client_id=" + clientId + "&duration=" + duration + "&response_type=code&redirect_uri=" + encodeURIComponent(redirectUri)
        });
        response.end();
    };
    /**
     * Completes the server-based OAuth 2.0 sign in process by exchanging the `authorizationCode`
     * for a `access_token`.
     *
     * @nodeOnly
     */
    UserSession.exchangeAuthorizationCode = function (options, authorizationCode) {
        var _a = __assign({
            portal: "https://www.arcgis.com/sharing/rest",
            duration: 20160,
            refreshTokenTTL: 1440
        }, options), portal = _a.portal, clientId = _a.clientId, duration = _a.duration, redirectUri = _a.redirectUri, refreshTokenTTL = _a.refreshTokenTTL;
        return fetchToken(portal + "/oauth2/token", {
            grant_type: "authorization_code",
            client_id: clientId,
            redirect_uri: redirectUri,
            code: authorizationCode
        }).then(function (response) {
            return new UserSession({
                clientId: clientId,
                portal: portal,
                redirectUri: redirectUri,
                refreshToken: response.refreshToken,
                refreshTokenTTL: refreshTokenTTL,
                refreshTokenExpires: new Date(Date.now() + (refreshTokenTTL - 1) * 1000),
                token: response.token,
                tokenExpires: response.expires,
                username: response.username
            });
        });
    };
    UserSession.deserialize = function (str) {
        var options = JSON.parse(str);
        return new UserSession({
            clientId: options.clientId,
            refreshToken: options.refreshToken,
            refreshTokenExpires: new Date(options.refreshTokenExpires),
            username: options.username,
            password: options.password,
            token: options.token,
            tokenExpires: new Date(options.tokenExpires),
            portal: options.portal,
            tokenDuration: options.tokenDuration,
            redirectUri: options.redirectUri,
            refreshTokenTTL: options.refreshTokenTTL
        });
    };
    /**
     * Translates authentication from the format used in the [ArcGIS API for JavaScript](https://developers.arcgis.com/javascript/).
     *
     * ```js
     * UserSession.fromCredential({
     *   userId: "jsmith",
     *   token: "secret"
     * });
     * ```
     *
     * @returns UserSession
     */
    UserSession.fromCredential = function (credential) {
        return new UserSession({
            portal: credential.server + "/sharing/rest",
            token: credential.token,
            username: credential.userId,
            tokenExpires: new Date(credential.expires)
        });
    };
    /**
     * Returns authentication in a format useable in the [ArcGIS API for JavaScript](https://developers.arcgis.com/javascript/).
     *
     * ```js
     * esriId.registerToken(session.toCredential());
     * ```
     *
     * @returns ICredential
     */
    UserSession.prototype.toCredential = function () {
        return {
            expires: this.tokenExpires.getTime(),
            server: this.portal,
            ssl: true,
            token: this.token,
            userId: this.username
        };
    };
    /**
     * Returns information about the currently logged in [user](https://developers.arcgis.com/rest/users-groups-and-items/user.htm). Subsequent calls will *not* result in additional web traffic.
     *
     * ```js
     * session.getUser()
     *   .then(response => {
     *     console.log(response.role); // "org_admin"
     *   })
     * ```
     *
     * @returns A Promise that will resolve with the data from the response.
     */
    UserSession.prototype.getUser = function (requestOptions) {
        var _this = this;
        if (this._user && this._user.username === this.username) {
            return new Promise(function (resolve) { return resolve(_this._user); });
        }
        else {
            var url = this.portal + "/community/users/" + encodeURIComponent(this.username);
            var options = __assign({ httpMethod: "GET", authentication: this }, requestOptions);
            return arcgisRestRequest.request(url, options).then(function (response) {
                _this._user = response;
                return response;
            });
        }
    };
    /**
     * Gets an appropriate token for the given URL. If `portal` is ArcGIS Online and
     * the request is to an ArcGIS Online domain `token` will be used. If the request
     * is to the current `portal` the current `token` will also be used. However if
     * the request is to an unknown server we will validate the server with a request
     * to our current `portal`.
     */
    UserSession.prototype.getToken = function (url, requestOptions) {
        if (/^https?:\/\/\S+\.arcgis\.com\/sharing\/rest/.test(this.portal) &&
            /^https?:\/\/\S+\.arcgis\.com.+/.test(url)) {
            return this.getFreshToken(requestOptions);
        }
        else if (new RegExp(this.portal).test(url)) {
            return this.getFreshToken(requestOptions);
        }
        else {
            return this.getTokenForServer(url, requestOptions);
        }
    };
    UserSession.prototype.toJSON = function () {
        return {
            clientId: this.clientId,
            refreshToken: this.refreshToken,
            refreshTokenExpires: this.refreshTokenExpires,
            username: this.username,
            password: this.password,
            token: this.token,
            tokenExpires: this.tokenExpires,
            portal: this.portal,
            tokenDuration: this.tokenDuration,
            redirectUri: this.redirectUri,
            refreshTokenTTL: this.refreshTokenTTL
        };
    };
    UserSession.prototype.serialize = function () {
        return JSON.stringify(this);
    };
    /**
     * Manually refreshes the current `token` and `tokenExpires`.
     */
    UserSession.prototype.refreshSession = function (requestOptions) {
        if (this.username && this.password) {
            return this.refreshWithUsernameAndPassword(requestOptions);
        }
        if (this.clientId && this.refreshToken) {
            return this.refreshWithRefreshToken();
        }
        return Promise.reject(new arcgisRestRequest.ArcGISAuthError("Unable to refresh token."));
    };
    /**
     * Validates that a given URL is properly federated with our current `portal`.
     * Attempts to use the internal `trustedServers` cache first.
     */
    UserSession.prototype.getTokenForServer = function (url, requestOptions) {
        var _this = this;
        var root = url.split("/rest/services/")[0];
        var existingToken = this.trustedServers[root];
        if (existingToken && existingToken.expires.getTime() > Date.now()) {
            return Promise.resolve(existingToken.token);
        }
        if (this._pendingTokenRequests[root]) {
            return this._pendingTokenRequests[root];
        }
        this._pendingTokenRequests[root] = arcgisRestRequest.request(root + "/rest/info")
            .then(function (response) {
            return response.owningSystemUrl;
        })
            .then(function (owningSystemUrl) {
            /**
             * if this server is not owned by this portal or the stand-alone
             * instance of ArcGIS Server doesn't advertise federation,
             * bail out with an error since we know we wont
             * be able to generate a token
             */
            if (!owningSystemUrl ||
                !new RegExp(owningSystemUrl).test(_this.portal)) {
                throw new arcgisRestRequest.ArcGISAuthError(url + " is not federated with " + _this.portal + ".", "NOT_FEDERATED");
            }
            return arcgisRestRequest.request(owningSystemUrl + "/sharing/rest/info", requestOptions);
        })
            .then(function (response) {
            return response.authInfo.tokenServicesUrl;
        })
            .then(function (tokenServicesUrl) {
            if (_this.token) {
                return generateToken(tokenServicesUrl, {
                    params: {
                        token: _this.token,
                        serverUrl: url,
                        expiration: _this.tokenDuration
                    }
                });
                // generate an entirely fresh token if necessary
            }
            else {
                return generateToken(tokenServicesUrl, {
                    params: {
                        username: _this.username,
                        password: _this.password,
                        expiration: _this.tokenDuration
                    }
                }).then(function (response) {
                    _this._token = response.token;
                    _this._tokenExpires = new Date(response.expires);
                    return response;
                });
            }
        })
            .then(function (response) {
            _this.trustedServers[root] = {
                expires: new Date(response.expires),
                token: response.token
            };
            return response.token;
        });
        return this._pendingTokenRequests[root];
    };
    /**
     * Returns an unexpired token for the current `portal`.
     */
    UserSession.prototype.getFreshToken = function (requestOptions) {
        var _this = this;
        if (this.token &&
            this.tokenExpires &&
            this.tokenExpires.getTime() > Date.now()) {
            return Promise.resolve(this.token);
        }
        if (!this._pendingTokenRequests[this.portal]) {
            this._pendingTokenRequests[this.portal] = this.refreshSession(requestOptions).then(function (session) {
                _this._pendingTokenRequests[_this.portal] = null;
                return session.token;
            });
        }
        return this._pendingTokenRequests[this.portal];
    };
    /**
     * Refreshes the current `token` and `tokenExpires` with `username` and
     * `password`.
     */
    UserSession.prototype.refreshWithUsernameAndPassword = function (requestOptions) {
        var _this = this;
        var options = __assign({ params: {
                username: this.username,
                password: this.password,
                expiration: this.tokenDuration
            } }, requestOptions);
        return generateToken(this.portal + "/generateToken", options).then(function (response) {
            _this._token = response.token;
            _this._tokenExpires = new Date(response.expires);
            return _this;
        });
    };
    /**
     * Refreshes the current `token` and `tokenExpires` with `refreshToken`.
     */
    UserSession.prototype.refreshWithRefreshToken = function (requestOptions) {
        var _this = this;
        if (this.refreshToken &&
            this.refreshTokenExpires &&
            this.refreshTokenExpires.getTime() < Date.now()) {
            return this.refreshRefreshToken(requestOptions);
        }
        var options = __assign({ params: {
                client_id: this.clientId,
                refresh_token: this.refreshToken,
                grant_type: "refresh_token"
            } }, requestOptions);
        return fetchToken(this.portal + "/oauth2/token", options).then(function (response) {
            _this._token = response.token;
            _this._tokenExpires = response.expires;
            return _this;
        });
    };
    /**
     * Exchanges an expired `refreshToken` for a new one also updates `token` and
     * `tokenExpires`.
     */
    UserSession.prototype.refreshRefreshToken = function (requestOptions) {
        var _this = this;
        var options = __assign({ params: {
                client_id: this.clientId,
                refresh_token: this.refreshToken,
                redirect_uri: this.redirectUri,
                grant_type: "exchange_refresh_token"
            } }, requestOptions);
        return fetchToken(this.portal + "/oauth2/token", options).then(function (response) {
            _this._token = response.token;
            _this._tokenExpires = response.expires;
            _this._refreshToken = response.refreshToken;
            _this._refreshTokenExpires = new Date(Date.now() + (_this.refreshTokenTTL - 1) * 60 * 1000);
            return _this;
        });
    };
    return UserSession;
}());

exports.ApplicationSession = ApplicationSession;
exports.UserSession = UserSession;
exports.fetchToken = fetchToken;
exports.generateToken = generateToken;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=auth.umd.js.map
