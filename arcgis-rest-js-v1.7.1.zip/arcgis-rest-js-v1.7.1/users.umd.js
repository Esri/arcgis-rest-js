/* @preserve
* @esri/arcgis-rest-users - v1.7.1 - Apache-2.0
* Copyright (c) 2017-2018 Esri, Inc.
* Fri Aug 10 2018 14:27:06 GMT-0700 (PDT)
*/
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@esri/arcgis-rest-request')) :
	typeof define === 'function' && define.amd ? define(['exports', '@esri/arcgis-rest-request'], factory) :
	(factory((global.arcgisRest = global.arcgisRest || {}),global.arcgisRest));
}(this, (function (exports,arcgisRestRequest) { 'use strict';

/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */



var __assign = Object.assign || function __assign(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
};

/* Copyright (c) 2018 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
/**
 * Get information about a user. This method has proven so generically useful that you can also call [`UserSession.getUser()`](../../auth/UserSession#getUser-summary).
 *
 * ```js
 * import { getUser } from '@esri/arcgis-rest-users';
 *
 * getUser("jsmith")
 *   .then(
 *     results => {
 *      // {
 *      //   firstName: "John",
 *      //   lastName: "Smith",
 *      //   tags: ["GIS Analyst", "City of Redlands"],
 *      //   created: 1258501046000
 *      //   etc.
 *      // };
 *   })
 * ```
 *
 * @param requestOptions - options to pass through in the request
 * @returns A Promise that will resolve with metadata about the user
 */
function getUser(requestOptions) {
    var url;
    var options = { httpMethod: "GET" };
    // if a username is passed, assume ArcGIS Online
    if (typeof requestOptions === "string") {
        url = "https://www.arcgis.com/sharing/rest/community/users/" + requestOptions;
    }
    else {
        // if an authenticated session is passed, default to that user/portal unless another username is provided manually
        var username = requestOptions.username || requestOptions.authentication.username;
        url = arcgisRestRequest.getPortalUrl(requestOptions) + "/community/users/" + encodeURIComponent(username);
        options = __assign({}, requestOptions, options);
    }
    // send the request
    return arcgisRestRequest.request(url, options);
}

exports.getUser = getUser;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=users.umd.js.map
