/* @esri/arcgis-rest-feature-service - v1.1.2 - Thu May 10 2018 15:55:26 GMT-0700 (PDT)
 * Copyright (c) 2018 Environmental Systems Research Institute, Inc.
 * Apache-2.0 */
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@esri/arcgis-rest-request')) :
	typeof define === 'function' && define.amd ? define(['exports', '@esri/arcgis-rest-request'], factory) :
	(factory((global.arcgisRest = global.arcgisRest || {}),global.arcgisRest));
}(this, (function (exports,arcgisRestRequest) { 'use strict';

/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */



var __assign = Object.assign || function __assign(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
};

/**
 * Get a feature by id
 *
 * @param requestOptions - Options for the request
 * @returns A Promise that will resolve with the feature.
 */
function getFeature(requestOptions) {
    var url = requestOptions.url + "/" + requestOptions.id;
    // default to a GET request
    var options = __assign({ httpMethod: "GET" }, requestOptions);
    return arcgisRestRequest.request(url, options).then(function (response) { return response.feature; });
}
/**
 * Query features
 *
 * @param requestOptions - Options for the request
 * @returns A Promise that will resolve with the query response.
 */
function queryFeatures(requestOptions) {
    // default to a GET request
    var options = __assign({
        params: {},
        httpMethod: "GET"
    }, requestOptions);
    // set default query parameters
    if (!options.params.where) {
        options.params.where = "1=1";
    }
    if (!options.params.outFields) {
        options.params.outFields = "*";
    }
    return arcgisRestRequest.request(requestOptions.url + "/query", options);
}
/**
 * Add features
 *
 * @param requestOptions - Options for the request
 * @returns A Promise that will resolve with the addFeatures response.
 */
function addFeatures(requestOptions) {
    var url = requestOptions.url + "/addFeatures";
    // edit operations are POST only
    var options = __assign({ params: {} }, requestOptions);
    // mixin, don't overwrite
    options.params.features = requestOptions.adds;
    return arcgisRestRequest.request(url, options);
}
/**
 * Update features
 *
 * @param requestOptions - Options for the request
 * @returns A Promise that will resolve with the updateFeatures response.
 */
function updateFeatures(requestOptions) {
    var url = requestOptions.url + "/updateFeatures";
    // edit operations are POST only
    var options = __assign({ params: {} }, requestOptions);
    // mixin, don't overwrite
    options.params.features = requestOptions.updates;
    return arcgisRestRequest.request(url, options);
}
/**
 * Delete features
 *
 * @param deleteFeaturesRequestOptions - Options for the request
 * @returns A Promise that will resolve with the deleteFeatures response.
 */
function deleteFeatures(requestOptions) {
    var url = requestOptions.url + "/deleteFeatures";
    // edit operations POST only
    var options = __assign({ params: {} }, requestOptions);
    // mixin, don't overwrite
    options.params.objectIds = requestOptions.deletes;
    return arcgisRestRequest.request(url, options);
}

exports.getFeature = getFeature;
exports.queryFeatures = queryFeatures;
exports.addFeatures = addFeatures;
exports.updateFeatures = updateFeatures;
exports.deleteFeatures = deleteFeatures;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=arcgis-rest-feature-service.umd.js.map
